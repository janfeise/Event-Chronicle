import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

let aiInstance: GoogleGenAI | null = null;
function getAi() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined. Please configure it in Settings > Secrets.");
    }
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiInstance;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Check if Gemini API key is configured
  app.get("/api/config", (req, res) => {
    const hasKey = !!process.env.GEMINI_API_KEY;
    res.json({
      hasGeminiKey: hasKey,
      message: hasKey 
        ? "Gemini API key is configured successfully." 
        : "Gemini API key is missing. Please add GEMINI_API_KEY in the Secrets panel."
    });
  });

  // Chat conversation and event extraction endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "messages array is required" });
      }

      // Check key first
      let ai;
      try {
        ai = getAi();
      } catch (err: any) {
        return res.status(500).json({ 
          error: "API Key Error", 
          message: err.message || "GEMINI_API_KEY is missing." 
        });
      }

      // Formulate the conversation history as context
      const formattedHistory = messages.map(msg => {
        const roleName = msg.role === "user" ? "用户 (User)" : "助手 (Assistant)";
        const timeStr = msg.time ? ` [时间: ${msg.time}]` : "";
        return `${roleName}${timeStr}: ${msg.content}`;
      }).join("\n");

      const prompt = `You are the backend AI for 'Event Chronicle' (Timeline-based Memory Engine).
Analyze the conversation transcript below, write a natural conversational reply to the last user message, and extract or update the structured chronicle timeline events based on the user's details.

Conversation Transcript:
${formattedHistory}

Your tasks:
1. Generate the natural conversational 'reply' as the Assistant. Keep the tone empathetic, warm, helpful, and natural (in Chinese).
2. Generate/Refine the list of 'events' extracted from the entire dialogue so far. Each event represents a concrete milestone, choice, mention, or action (e.g. buying a cat, getting medical checkup, feeling relieved, advice given).
   - If previous events are already established, keep them and align them to the conversation timeline.
   - Extract any new event that is mentioned or implied.
   - Give each event:
     - title: A short title in Chinese (e.g., "养了一只橘猫")
     - description: A clear, concise summary in Chinese (e.g., "用户最近养了一只橘猫，名叫奶糖，特别粘人。")
     - tag: A category. Choose strictly from: "宠物", "健康", "情感", "建议", "日常", "其他"
     - time: The relevant timestamp (typically aligning with the message time e.g., "10:00" or relative e.g., "昨天")

Respond strictly with a JSON object containing 'reply' and 'events'.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: { 
                type: Type.STRING,
                description: "The next reply to the user from the assistant" 
              },
              events: {
                type: Type.ARRAY,
                description: "All events extracted from the whole conversation so far",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { 
                      type: Type.STRING,
                      description: "Short concise title of the event" 
                    },
                    description: { 
                      type: Type.STRING,
                      description: "Detailed description of the event" 
                    },
                    tag: { 
                      type: Type.STRING,
                      description: "The event category: 宠物, 健康, 情感, 建议, 日常, 其他" 
                    },
                    time: { 
                      type: Type.STRING,
                      description: "The timestamp of when the event happened or was mentioned, strictly formatted like 'HH:mm' or '昨天', '今天'" 
                    }
                  },
                  required: ["title", "description", "tag", "time"]
                }
              }
            },
            required: ["reply", "events"]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("No response text received from Gemini.");
      }

      const parsedData = JSON.parse(responseText.trim());
      res.json(parsedData);
    } catch (error: any) {
      console.error("Error in /api/chat:", error);
      res.status(500).json({ 
        error: "Internal Server Error", 
        message: error.message || "Failed to process chat with Gemini." 
      });
    }
  });

  // Serve static files / Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
