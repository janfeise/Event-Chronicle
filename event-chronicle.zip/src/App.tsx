/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Send,
  Bot,
  User,
  Sparkles,
  Clock,
  Calendar,
  Heart,
  Activity,
  Trash2,
  RefreshCw,
  Loader2,
  AlertCircle,
  Plus,
  BookOpen,
  Edit2,
  X,
  Check,
  Info
} from "lucide-react";

// Types for Chat Messages
interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  time: string;
}

// Types for Timeline Events
interface TimelineEvent {
  id: string;
  title: string;
  description: string;
  tag: string; // 宠物, 健康, 情感, 建议, 日常, 其他
  time: string;
}

// Initial design replicas perfectly mapping to the visual screenshot
const MOCK_MESSAGES: Message[] = [
  {
    id: "m1",
    role: "user",
    content: "我最近养了一只橘猫，取名叫奶糖，特别粘人。",
    time: "10:00"
  },
  {
    id: "m2",
    role: "assistant",
    content: "奶糖这名字真好听！它现在有多大了？",
    time: "10:00"
  },
  {
    id: "m3",
    role: "user",
    content: "刚三个月，还是个小家伙。",
    time: "10:01"
  },
  {
    id: "m4",
    role: "assistant",
    content: "三个月正是活泼好动的时候呢。对了，带它去检查过了吗？",
    time: "10:01"
  },
  {
    id: "m5",
    role: "user",
    content: "昨天刚带它去宠物医院做了体检。",
    time: "10:02"
  },
  {
    id: "m6",
    role: "assistant",
    content: "体检结果怎么样？",
    time: "10:02"
  },
  {
    id: "m7",
    role: "user",
    content: "一切正常，医生说很健康，我放心多了。",
    time: "10:03"
  },
  {
    id: "m8",
    role: "assistant",
    content: "那太好了。小猫这个阶段要多注意营养。",
    time: "10:03"
  }
];

const MOCK_EVENTS: TimelineEvent[] = [
  {
    id: "e1",
    title: "养了一只橘猫",
    description: "用户最近养了一只橘猫，名叫奶糖，特别粘人。",
    tag: "宠物",
    time: "10:00"
  },
  {
    id: "e2",
    title: "橘猫奶糖三个月大",
    description: "奶糖刚三个月，还是个小家伙。",
    tag: "宠物",
    time: "10:01"
  },
  {
    id: "e3",
    title: "带奶糖去做体检",
    description: "用户昨天带奶糖去宠物医院做了体检。",
    tag: "健康",
    time: "10:02"
  },
  {
    id: "e4",
    title: "体检结果正常",
    description: "奶糖体检结果一切正常，医生说很健康。",
    tag: "健康",
    time: "10:02"
  },
  {
    id: "e5",
    title: "用户对奶糖感到放心",
    description: "用户得知奶糖健康后，感到放心。",
    tag: "情感",
    time: "10:03"
  },
  {
    id: "e6",
    title: "关注小猫营养问题",
    description: "助手建议小猫这个阶段要多注意营养。",
    tag: "建议",
    time: "10:03"
  }
];

// Fallback logic for intelligent extraction when Gemini API is offline/not configured
const SANDBOX_KEYWORDS = [
  { keywords: ["生病", "医院", "疼", "感冒", "医生", "体检", "健康", "疫苗"], title: "健康状况更新", tag: "健康", desc: "对话中提到健康、医疗、体检相关进展或诊断。" },
  { keywords: ["猫", "狗", "宠物", "猫粮", "奶糖", "哈士奇", "铲屎"], title: "宠物生活记录", tag: "宠物", desc: "对话涉及宠物照顾、玩耍、日常喂养等互动。" },
  { keywords: ["开心", "难过", "伤心", "抑郁", "感动", "放心", "焦虑", "紧张"], title: "情绪/心理波动", tag: "情感", desc: "记录了用户目前产生的情绪宣泄、焦虑缓解或幸福时刻。" },
  { keywords: ["建议", "多喝水", "应该", "推荐", "指导", "营养", "注意"], title: "行动保健建议", tag: "建议", desc: "记录了助手或专业人士给出的改善、注意或保健方案。" },
  { keywords: ["旅行", "机票", "酒店", "出发", "风景", "爬山", "旅游"], title: "出行与旅程", tag: "日常", desc: "用户开启或规划了新的旅行和发现之旅。" },
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [events, setEvents] = useState<TimelineEvent[]>(MOCK_EVENTS);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  // Backend key state
  const [hasGeminiKey, setHasGeminiKey] = useState<boolean | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Manual event form states
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [newEvTitle, setNewEvTitle] = useState("");
  const [newEvDesc, setNewEvDesc] = useState("");
  const [newEvTag, setNewEvTag] = useState("宠物");
  const [newEvTime, setNewEvTime] = useState("");

  // Edit event states
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDesc, setEditDesc] = useState("");
  const [editTag, setEditTag] = useState("");
  const [editTime, setEditTime] = useState("");

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Check key configuration on startup
  useEffect(() => {
    fetch("/api/config")
      .then(res => res.json())
      .then(data => {
        setHasGeminiKey(data.hasGeminiKey);
      })
      .catch(() => {
        setHasGeminiKey(false);
      });
  }, []);

  // Safe scroll to down
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Handle message sending
  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputValue.trim()) return;

    const userText = inputValue;
    setInputValue("");

    // Create current time string
    const now = new Date();
    const timeString = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newUserMsg: Message = {
      id: Math.random().toString(36).substring(7),
      role: "user",
      content: userText,
      time: timeString
    };

    const updatedMessages = [...messages, newUserMsg];
    setMessages(updatedMessages);
    setIsLoading(true);
    setErrorMessage(null);

    try {
      if (hasGeminiKey) {
        // Run full-stack Gemini API call
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ messages: updatedMessages })
        });

        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.message || "服务器响应异常");
        }

        const data = await response.json();
        
        // Add Assistant reply
        const assistantMsg: Message = {
          id: Math.random().toString(36).substring(7),
          role: "assistant",
          content: data.reply || "非常抱歉，我未能生成回复。",
          time: timeString
        };

        setMessages(prev => [...prev, assistantMsg]);

        // Map events with unique id
        if (data.events && Array.isArray(data.events)) {
          const updatedEvents: TimelineEvent[] = data.events.map((evt: any, index: number) => ({
            id: `evt-${Date.now()}-${index}`,
            title: evt.title || "未知事件",
            description: evt.description || "",
            tag: evt.tag || "其他",
            time: evt.time || timeString
          }));
          setEvents(updatedEvents);
        }
      } else {
        // High fidelity sandbox simulation mode when Gemini API key is missing
        await new Promise(resolve => setTimeout(resolve, 1400));

        // 1. Generate sandbox message reply
        let replyText = `听到您说"${userText.slice(0, 10)}"，这听起来很重要。我已经将相关信息记录到了时间线引擎中！`;
        if (userText.includes("猫") || userText.includes("狗") || userText.includes("宠物")) {
          replyText = "动物是非常棒的伴侣，多花时间照顾和喂养它。要注意小猫小狗的阶段营养，并且定期体检。";
        } else if (userText.includes("累") || userText.includes("压力") || userText.includes("难过")) {
          replyText = "最近压力太大了吗？没关系，多出去散散步，或者找朋友聊天，调整好心情。希望我生成的记忆树能给你带去一丝慰藉。";
        } else if (userText.includes("体检") || userText.includes("医生") || userText.includes("医院")) {
          replyText = "体检非常关键！如果结果都正常就可以大舒一口气了，祝愿身体一直健康！";
        } else if (userText.includes("谢谢") || userText.includes("真好")) {
          replyText = "我也很高兴能帮到您！我会一直在右侧为您自动维护最精彩的人生记忆时间线。";
        }

        // 2. Extract state matching keywords
        let matchedRule = SANDBOX_KEYWORDS.find(rule => 
          rule.keywords.some(kw => userText.includes(kw))
        );

        let newEvents = [...events];
        if (matchedRule) {
          newEvents.push({
            id: `evt-${Date.now()}`,
            title: `${matchedRule.title} · ${userText.slice(0, 6)}`,
            description: `用户指出：“${userText}”，已被系统识别归入 [${matchedRule.tag}] 记忆板块。`,
            tag: matchedRule.tag,
            time: timeString
          });
        } else {
          newEvents.push({
            id: `evt-${Date.now()}`,
            title: "对话日常提及",
            description: `用户说道：“${userText}”。内容分析无明显其他标签，已自动归档存入日常。`,
            tag: "日常",
            time: timeString
          });
        }

        // Add reply
        setMessages(prev => [...prev, {
          id: Math.random().toString(36).substring(7),
          role: "assistant",
          content: replyText,
          time: timeString
        }]);
        setEvents(newEvents);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "获取 AI 回复失败，请重试或在顶部切换演示模式");
    } finally {
      setIsLoading(false);
    }
  };

  // Helper styles for badges and timelines
  const getTagMeta = (tag: string) => {
    switch (tag) {
      case "宠物":
        return {
          bg: "bg-[#eef2ff] text-[#4f46e5] border border-[#e0e7ff]",
          marker: "bg-[#4f46e5]",
          icon: <BookOpen className="w-3 h-3 mr-1" />
        };
      case "健康":
        return {
          bg: "bg-[#fffbeb] text-[#d97706] border border-[#fef3c7]",
          marker: "bg-[#f59e0b]",
          icon: <Activity className="w-3 h-3 mr-1" />
        };
      case "情感":
        return {
          bg: "bg-[#faf5ff] text-[#9333ea] border border-[#f3e8ff]",
          marker: "bg-[#a855f7]",
          icon: <Heart className="w-3 h-3 mr-1" />
        };
      case "建议":
        return {
          bg: "bg-[#ecfdf5] text-[#059669] border border-[#d1fae5]",
          marker: "bg-[#10b981]",
          icon: <Sparkles className="w-3 h-3 mr-1" />
        };
      case "日常":
        return {
          bg: "bg-[#f0fdf4] text-[#16a34a] border border-[#dcfce7]",
          marker: "bg-[#22c55e]",
          icon: <Calendar className="w-3 h-3 mr-1" />
        };
      default:
        return {
          bg: "bg-slate-50 text-slate-600 border border-slate-200",
          marker: "bg-slate-400",
          icon: <Clock className="w-3 h-3 mr-1" />
        };
    }
  };

  // Clear memory handler
  const clearMemory = () => {
    setMessages([
      {
        id: "sys1",
        role: "assistant",
        content: "事件时间线记忆引擎已重置。您可以开始和我交谈，比如：“我最近三个月计划去西藏旅游”，我将全流程智能为您抽取日程和记忆时间线！",
        time: "10:00"
      }
    ]);
    setEvents([]);
  };

  // Restore mockup demo data
  const resetToTemplate = () => {
    setMessages(MOCK_MESSAGES);
    setEvents(MOCK_EVENTS);
    setEditingEventId(null);
    setShowAddEvent(false);
  };

  // Handle manually adding an event
  const handleAddNewEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEvTitle.trim()) return;

    const finalTime = newEvTime.trim() || new Date().toTimeString().slice(0, 5);

    const newEv: TimelineEvent = {
      id: `manual-evt-${Date.now()}`,
      title: newEvTitle,
      description: newEvDesc || "用户手动添加的独立纪念事件。",
      tag: newEvTag,
      time: finalTime
    };

    setEvents(prev => [...prev, newEv]);
    setNewEvTitle("");
    setNewEvDesc("");
    setNewEvTime("");
    setShowAddEvent(false);
  };

  // Delete specific event
  const handleDeleteEvent = (id: string) => {
    setEvents(prev => prev.filter(e => e.id !== id));
    if (editingEventId === id) setEditingEventId(null);
  };

  // Start editing mode for event
  const startEditing = (evt: TimelineEvent) => {
    setEditingEventId(evt.id);
    setEditTitle(evt.title);
    setEditDesc(evt.description);
    setEditTag(evt.tag);
    setEditTime(evt.time);
  };

  // Save changes to event
  const saveEventEdit = (id: string) => {
    setEvents(prev => prev.map(e => {
      if (e.id === id) {
        return {
          ...e,
          title: editTitle,
          description: editDesc,
          tag: editTag,
          time: editTime
        };
      }
      return e;
    }));
    setEditingEventId(null);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 font-sans flex flex-col" id="app_root">
      
      {/* Top Configuration Bar */}
      <div className="bg-white border-b border-slate-200 px-6 py-2.5 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-3" id="top_bar">
        <div className="flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full inline-block ${hasGeminiKey ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400 animate-pulse'}`}></span>
          <span className="font-medium">
            {hasGeminiKey === null 
              ? "正在检测系统联结..." 
              : hasGeminiKey 
                ? "双向全栈联动中: Gemini 3.5 Flash 智能提取已启用!" 
                : "沙盒演示模式：当前正在由独立客户端推理记忆标签"}
          </span>
        </div>
        <div className="flex items-center gap-3.5">
          <button 
            type="button"
            onClick={resetToTemplate} 
            className="text-[#4f46e5] hover:text-[#4338ca] bg-[#eef2ff] px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 transition-all"
            id="btn_reset"
          >
            <RefreshCw className="w-3.5 h-3.5" /> 还原图片预设
          </button>
          {!hasGeminiKey && (
            <span className="text-amber-600 font-semibold bg-amber-50 px-2 py-1 rounded border border-amber-200/50">
              💡 开发者提示: 在设置 - Secrets中配置 GEMINI_API_KEY 即可接入真机 AI。
            </span>
          )}
        </div>
      </div>

      {/* Main Container - Split Chat/Timeline layout */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden max-w-[1700px] w-full mx-auto" id="main_pane">
        
        {/* Left Column: Chat Area */}
        <div className="flex-1 lg:max-w-[50%] flex flex-col border-r border-slate-200 bg-white" id="left_column">
          
          {/* Main App Title / Brand Header */}
          <div className="p-6 border-b border-slate-100 flex items-center justify-between" id="app_header">
            <div className="flex items-center gap-3">
              {/* Event Chronicle unique logo */}
              <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-indigo-200/60 relative overflow-hidden" id="logo_outer">
                <span className="font-display font-black text-xl italic tracking-wider">EC</span>
                <div className="absolute right-0 bottom-0 w-4 h-4 bg-amber-300 rounded-tl-lg flex items-center justify-center">
                  <div className="w-2.5 h-2.5 rounded-full border-2 border-slate-900 border-t-transparent animate-spin"></div>
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold tracking-tight text-slate-900" id="brand_title">
                    Event Chronicle
                  </h1>
                </div>
                <p className="text-xs text-slate-400 font-semibold tracking-wide" id="brand_subtitle">
                  Timeline-based Memory Engine
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={clearMemory}
                title="清空对话"
                className="p-2.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                id="btn_clear"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Chat Messages Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6" id="messages_box">
            <AnimatePresence initial={false}>
              {messages.map((msg) => {
                const isUser = msg.role === "user";
                return (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col space-y-1.5"
                    id={`msg_wrap_${msg.id}`}
                  >
                    {/* Header line */}
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                        isUser 
                          ? "bg-blue-500 text-white shadow-sm" 
                          : "bg-slate-900 text-slate-100 shadow-sm"
                      }`}>
                        {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                      </div>
                      <span className="text-xs font-bold text-slate-600">
                        {isUser ? "User" : "Assistant"}
                      </span>
                    </div>

                    {/* Chat Bubble matching exact image dimensions */}
                    <div className="pl-9 pr-2">
                      <div className={`rounded-2xl py-3.5 px-4 flex justify-between items-start gap-4 shadow-xs transition-all ${
                        isUser 
                          ? "bg-[#ebf4ff] border border-blue-100 text-slate-900" 
                          : "bg-white border border-[#edf1f7] text-slate-900 shadow-sm"
                      }`}>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap flex-1 hover:text-slate-900 font-medium">
                          {msg.content}
                        </p>
                        <span className="text-[11px] text-slate-400 font-mono self-end pt-1">
                          {msg.time}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {/* AI Generation Loading state */}
            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col space-y-1.5"
                id="loading_spinner"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-bold text-slate-500">Assistant</span>
                </div>
                <div className="pl-9">
                  <div className="inline-flex items-center gap-2 rounded-2xl py-3 px-4 bg-slate-50 border border-slate-100 text-sm text-slate-500">
                    <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
                    <span className="text-xs font-semibold animate-pulse">正在提取事件并在对齐时间线...</span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Error alerts */}
            {errorMessage && (
              <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl flex items-start gap-3 text-xs text-rose-700" id="error_pane">
                <AlertCircle className="w-4.5 h-4.5 text-rose-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">时间线引擎响应错误</p>
                  <p className="mt-1 text-rose-600/90">{errorMessage}</p>
                </div>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Form container */}
          <div className="p-5 border-t border-slate-100 bg-white" id="composer_section">
            <form onSubmit={handleSend} className="flex gap-3">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Type your message..."
                disabled={isLoading}
                className="flex-1 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 shadow-sm transition-all"
                id="message_input"
              />
              <button
                type="submit"
                disabled={isLoading || !inputValue.trim()}
                className="w-12 h-11 bg-[#3b82f6] hover:bg-blue-600 active:bg-blue-700 text-white rounded-xl flex items-center justify-center transition-all shadow-sm active:scale-95 disabled:opacity-40 disabled:scale-100 disabled:pointer-events-none"
                id="btn_submit_message"
              >
                <Send className="w-4.5 h-4.5" />
              </button>
            </form>
          </div>

        </div>

        {/* Right Column: Interactive Event Timeline */}
        <div className="flex-1 bg-[#f8fafc] flex flex-col h-[70vh] lg:h-auto overflow-hidden" id="right_column">
          
          {/* Header of events list */}
          <div className="p-6 border-b border-sky-100/55 bg-white flex items-center justify-between" id="timeline_header">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 border border-slate-200 bg-slate-50 rounded-lg flex items-center justify-center" id="calendar_box">
                <Calendar className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="font-bold text-base text-slate-900" id="timeline_title_text">
                  事件提取与时间线
                </h2>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {/* Counts of events badge replica of image */}
              <span className="bg-[#e6fcf4] text-[#16a34a] text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-[#bbf7d0]" id="badge_counter">
                <span className="w-1.5 h-1.5 rounded-full bg-[#16a34a] animate-pulse"></span>
                {events.length} 个事件已提取
              </span>

              {/* Add event button manually */}
              <button
                type="button"
                onClick={() => setShowAddEvent(!showAddEvent)}
                className={`p-1.5 rounded-lg border transition-all text-slate-500 hover:text-indigo-600 hover:bg-slate-50 ${
                  showAddEvent ? "bg-indigo-50 border-indigo-200 text-indigo-600" : "border-slate-200"
                }`}
                title="手动添加事件"
                id="btn_toggle_add_event"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Timeline Scroll wrap */}
          <div className="flex-1 overflow-y-auto px-6 py-6 relative" id="timeline_body_pane">
            
            {/* Slide block for Manual adding of events */}
            <AnimatePresence>
              {showAddEvent && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-6 bg-white border border-indigo-100 rounded-xl p-4 shadow-sm space-y-3 overflow-hidden"
                  id="add_event_panel"
                >
                  <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                    <h4 className="font-bold text-xs text-indigo-600 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" /> 手动在时间轴上创建事件
                    </h4>
                    <button 
                      type="button"
                      onClick={() => setShowAddEvent(false)} 
                      className="text-slate-400 hover:text-slate-600"
                      id="btn_close_add_form"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <form onSubmit={handleAddNewEvent} className="space-y-3 text-xs">
                    <div>
                      <label className="block text-slate-500 font-semibold mb-1">事件标题*</label>
                      <input 
                        type="text" 
                        required 
                        value={newEvTitle} 
                        onChange={e => setNewEvTitle(e.target.value)}
                        placeholder="例：带奶糖打疫苗" 
                        className="w-full border border-slate-200 p-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        id="form_add_title"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-slate-500 font-semibold mb-1">标签类别</label>
                        <select 
                          value={newEvTag} 
                          onChange={e => setNewEvTag(e.target.value)} 
                          className="w-full border border-slate-200 p-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          id="form_add_tag"
                        >
                          <option value="宠物">宠物</option>
                          <option value="健康">健康</option>
                          <option value="情感">情感</option>
                          <option value="建议">建议</option>
                          <option value="日常">日常</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-500 font-semibold mb-1">发生时间</label>
                        <input 
                          type="text" 
                          value={newEvTime} 
                          onChange={e => setNewEvTime(e.target.value)} 
                          placeholder="例：10:05 或 昨天" 
                          className="w-full border border-slate-200 p-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          id="form_add_time"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-500 font-semibold mb-1">详细描述</label>
                      <textarea 
                        value={newEvDesc} 
                        onChange={e => setNewEvDesc(e.target.value)}
                        placeholder="记录与奶糖互动的点点滴滴..." 
                        rows={2}
                        className="w-full border border-slate-200 p-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        id="form_add_desc"
                      />
                    </div>

                    <button 
                      type="submit" 
                      className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg transition-all"
                      id="btn_submit_add_event"
                    >
                      提交存入时间树
                    </button>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Empty view check */}
            {events.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center py-20 p-8" id="empty_slate">
                <Info className="w-12 h-12 text-slate-300 mb-3" />
                <p className="font-semibold text-sm">暂无事件。请说一点关于自己的日常吧！</p>
                <p className="text-xs text-slate-400 mt-1">
                  比如猫咪的情况、健康的打算。AI 记忆引擎会在后台自动归类出精美的时间轴标签。
                </p>
              </div>
            ) : (
              <div className="relative pl-7 md:pl-10 space-y-6" id="timeline_axis_wrap">
                
                {/* Visual axis line matching prototype background lines */}
                <div className="absolute left-[9.5px] md:left-[13.5px] top-6 bottom-6 w-[2.5px] bg-[#eef2f6]" />

                <AnimatePresence initial={false}>
                  {events.map((evt, idx) => {
                    const tagMeta = getTagMeta(evt.tag);
                    const isEditing = editingEventId === evt.id;

                    return (
                      <motion.div
                        key={evt.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.25, delay: idx * 0.05 }}
                        className="relative"
                        id={`evt_item_${evt.id}`}
                      >
                        {/* Dot on Timeline Axis with adaptive coloring */}
                        <div className={`absolute -left-[23px] md:-left-[29px] top-6 w-[11px] h-[11px] rounded-full ring-4 ring-white ${tagMeta.marker} z-10 transition-colors`} />

                        {/* Card box */}
                        <div className="bg-white border border-[#f0f3f8] rounded-xl p-4 hover:shadow-md hover:border-slate-200 transition-all group" id={`evt_card_${evt.id}`}>
                          {isEditing ? (
                            // Editing view
                            <div className="space-y-3 text-xs" id="editing_box">
                              <div className="flex gap-2">
                                <input 
                                  type="text" 
                                  value={editTitle} 
                                  onChange={e => setEditTitle(e.target.value)} 
                                  className="font-bold flex-1 border border-slate-200 p-1.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500" 
                                />
                                <input 
                                  type="text" 
                                  value={editTime} 
                                  onChange={e => setEditTime(e.target.value)} 
                                  className="w-16 text-center font-mono border border-slate-200 p-1.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500" 
                                />
                              </div>
                              <textarea 
                                value={editDesc} 
                                onChange={e => setEditDesc(e.target.value)} 
                                className="w-full text-slate-500 border border-slate-200 p-1.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500" 
                                rows={2}
                              />
                              <div className="flex justify-between items-center">
                                <select 
                                  value={editTag} 
                                  onChange={e => setEditTag(e.target.value)} 
                                  className="border border-slate-200 p-1 rounded-lg"
                                >
                                  <option value="宠物">宠物</option>
                                  <option value="健康">健康</option>
                                  <option value="情感">情感</option>
                                  <option value="建议">建议</option>
                                  <option value="日常">日常</option>
                                </select>
                                <div className="flex gap-1.5">
                                  <button 
                                    type="button" 
                                    onClick={() => setEditingEventId(null)} 
                                    className="p-1 px-2.5 text-slate-400 bg-slate-100 hover:bg-slate-200 rounded-md font-semibold"
                                  >
                                    取消
                                  </button>
                                  <button 
                                    type="button" 
                                    onClick={() => saveEventEdit(evt.id)} 
                                    className="p-1 px-2.5 text-white bg-indigo-600 hover:bg-indigo-700 rounded-md font-semibold flex items-center gap-1"
                                  >
                                    <Check className="w-3.5 h-3.5" /> 保存
                                  </button>
                                </div>
                              </div>
                            </div>
                          ) : (
                            // Normal display view
                            <div>
                              <div className="flex justify-between items-start gap-4">
                                <h3 className="font-bold text-[14px] text-slate-950 leading-relaxed font-sans">
                                  {evt.title}
                                </h3>
                                <span className="text-xs text-slate-400 font-mono select-none pt-0.5 whitespace-nowrap">
                                  {evt.time}
                                </span>
                              </div>

                              <p className="text-xs text-slate-500 leading-relaxed font-normal mt-1.5 mb-3">
                                {evt.description}
                              </p>

                              <div className="flex items-center justify-between">
                                {/* Tag label */}
                                <span className={`inline-flex items-center text-[10px] font-bold px-2.5 py-0.5 rounded-md ${tagMeta.bg}`}>
                                  {tagMeta.icon}
                                  {evt.tag}
                                </span>

                                {/* Quick inline utility actions on hover */}
                                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => startEditing(evt)}
                                    className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all"
                                    title="编辑此事件"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteEvent(evt.id)}
                                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-all"
                                    title="删除此事件"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                      </motion.div>
                    );
                  })}
                </AnimatePresence>
                
              </div>
            )}
          </div>

          {/* Sincere Footer matching mockup */}
          <div className="py-4 text-center border-t border-slate-100 bg-white" id="author_footer">
            <span className="text-xs text-slate-400 font-mono tracking-wider font-semibold">
              ✧ Event Chronicle Demo · Timeline-based Memory ✧
            </span>
          </div>

        </div>

      </div>

    </div>
  );
}
